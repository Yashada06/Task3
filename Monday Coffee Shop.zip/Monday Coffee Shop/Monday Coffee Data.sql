create table cities (city_id integer , city_name char , population integer , estimated_rent integer , city_rank integer);

select * from city;

select * from customers;

select * from products;

select * from sales;

INSERT INTO cities (city_id, city_name, population, estimated_rent, city_rank)
VALUES
    (1, 'Bangalore', 12300000, 29700, 1),
    (2, 'Chennai', 11100000, 17100, 6),
    (3, 'Pune', 7500000, 15300, 9),
    (4, 'Jaipur', 4000000, 10800, 8),
	(5, 'Delhi', 31000000, 22500, 3),
    (6, 'Mumbai', 20400000, 31500, 2),
    (7, 'Hyderabad', 10000000, 22500, 4),
	(8, 'Ahmedabad', 8300000, 14400, 5),
    (9, 'Kolkata', 14900000, 16200, 7),
    (10, 'Surat', 7200000, 13500, 10);

	select * from cities;

	SELECT 
	city_name,
	ROUND(
	(population * 0.25)/1000000, 
	2) as coffee_consumers_in_millions,
	city_rank
FROM cities
ORDER BY 2 DESC

select sum(total) as total_revenue
from sales 
where 
extract (year from sale_date)=2023
and
extract (quarter from sale_date)=4

SELECT 
	p.product_name,
	COUNT(s.sale_id) as total_orders
FROM products as p
LEFT JOIN
sales as s
ON s.product_id = p.product_id
GROUP BY 1
ORDER BY 2 DESC;

SELECT 
	ci.city_name,
	SUM(s.total) as total_revenue,
	COUNT(DISTINCT s.customer_id) as total_cx,
	ROUND(
			SUM(s.total)::numeric/
				COUNT(DISTINCT s.customer_id)::numeric
			,2) as avg_sale_pr_cx
	
FROM sales as s
JOIN customers as c
ON s.customer_id = c.customer_id
JOIN cities as ci
ON ci.city_id = c.city_id
GROUP BY 1
ORDER BY 2 DESC


SELECT * 
FROM -- table
(
	SELECT 
		ci.city_name,
		p.product_name,
		COUNT(s.sale_id) as total_orders,
		DENSE_RANK() OVER(PARTITION BY ci.city_name ORDER BY COUNT(s.sale_id) DESC) as rank
	FROM sales as s
	JOIN products as p
	ON s.product_id = p.product_id
	JOIN customers as c
	ON c.customer_id = s.customer_id
	JOIN cities as ci
	ON ci.city_id = c.city_id
	GROUP BY 1, 2
	-- ORDER BY 1, 3 DESC
) as t1
WHERE rank <= 3


SELECT * FROM products;



SELECT 
	ci.city_name,
	COUNT(DISTINCT c.customer_id) as unique_cx
FROM cities as ci
LEFT JOIN
customers as c
ON c.city_id = ci.city_id
JOIN sales as s
ON s.customer_id = c.customer_id
WHERE 
	s.product_id IN (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14)
GROUP BY 1






