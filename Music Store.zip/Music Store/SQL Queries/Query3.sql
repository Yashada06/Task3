
SELECT total 
FROM invoice
ORDER BY total DESC


